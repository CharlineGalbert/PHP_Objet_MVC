<h1><?= $article->titre;?></h1>
<p><?= $article->description;?></p>