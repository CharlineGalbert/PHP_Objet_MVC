<section class="container mt-4">
    <h1 class="text-center">Se connecter</h1>
    <?= $form; ?>
</section>